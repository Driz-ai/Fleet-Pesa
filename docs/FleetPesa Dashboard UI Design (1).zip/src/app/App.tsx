import { useState } from "react";
import {
  LayoutDashboard, Truck, Bell, Wrench, Users, Settings, LogOut,
  TrendingUp, AlertTriangle, CheckCircle, Clock, ChevronRight,
  X, ArrowLeft, Phone, Flag, Eye, EyeOff, Filter, Bike,
  Zap, History, RotateCcw,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";

// ─── Types ───────────────────────────────────────────────────────────────────

type Role = "owner" | "driver";
type SidebarTab = "dashboard" | "fleet" | "maintenance";

interface Driver {
  id: number;
  name: string;
  initials: string;
  vehicle: string;
  type: "Matatu" | "Boda Boda";
  status: "paid" | "short" | "late" | "overdue";
  collected: number;
  expected: number;
  time: string;
  phone: string;
}

interface VehicleHistory {
  date: string;
  amount: number;
  expected: number;
  status: string;
}

interface Vehicle {
  id: number;
  plate: string;
  type: "Matatu" | "Boda Boda";
  driver: string;
  driverInitials: string;
  status: "operational" | "maintenance";
  mileage: number;
  nextService: number;
  lastServiceDate: string;
  remittanceHistory: VehicleHistory[];
}

interface MaintenanceAlert {
  id: number;
  plate: string;
  driver: string;
  type: "Matatu" | "Boda Boda";
  urgency: "critical" | "high" | "medium" | "low";
  issue: string;
  mileage: number;
  dueAt: number;
  daysOverdue: number;
  serviced?: boolean;
}

// ─── Data ────────────────────────────────────────────────────────────────────

const REVENUE_DATA = [
  { day: "Mon", revenue: 38500 },
  { day: "Tue", revenue: 45200 },
  { day: "Wed", revenue: 41800 },
  { day: "Thu", revenue: 39600 },
  { day: "Fri", revenue: 52400 },
  { day: "Sat", revenue: 61800 },
  { day: "Sun", revenue: 47850 },
];

const DRIVERS: Driver[] = [
  { id: 1, name: "Joseph Kamau", initials: "JK", vehicle: "KBZ 234K", type: "Matatu", status: "paid", collected: 4500, expected: 4500, time: "08:42 AM", phone: "+254 712 345 678" },
  { id: 2, name: "Grace Wanjiku", initials: "GW", vehicle: "KCA 891B", type: "Boda Boda", status: "short", collected: 1200, expected: 1500, time: "09:15 AM", phone: "+254 723 456 789" },
  { id: 3, name: "Peter Omondi", initials: "PO", vehicle: "KDG 567M", type: "Matatu", status: "late", collected: 0, expected: 4500, time: "—", phone: "+254 734 567 890" },
  { id: 4, name: "Mary Achieng", initials: "MA", vehicle: "KBF 112A", type: "Boda Boda", status: "paid", collected: 1500, expected: 1500, time: "07:55 AM", phone: "+254 745 678 901" },
  { id: 5, name: "David Mwangi", initials: "DM", vehicle: "KDD 789P", type: "Matatu", status: "overdue", collected: 0, expected: 4500, time: "—", phone: "+254 756 789 012" },
  { id: 6, name: "Faith Njeri", initials: "FN", vehicle: "KCE 445T", type: "Boda Boda", status: "paid", collected: 1500, expected: 1500, time: "10:03 AM", phone: "+254 767 890 123" },
  { id: 7, name: "Samuel Kipchoge", initials: "SK", vehicle: "KBM 678G", type: "Matatu", status: "paid", collected: 4500, expected: 4500, time: "11:20 AM", phone: "+254 778 901 234" },
  { id: 8, name: "Esther Nyambura", initials: "EN", vehicle: "KCH 321R", type: "Boda Boda", status: "short", collected: 900, expected: 1500, time: "09:47 AM", phone: "+254 789 012 345" },
];

const VEHICLES: Vehicle[] = [
  {
    id: 1, plate: "KBZ 234K", type: "Matatu", driver: "Joseph Kamau", driverInitials: "JK",
    status: "operational", mileage: 82450, nextService: 85000, lastServiceDate: "5 Aug 2025",
    remittanceHistory: [
      { date: "Sun Aug 18", amount: 4500, expected: 4500, status: "paid" },
      { date: "Sat Aug 17", amount: 4500, expected: 4500, status: "paid" },
      { date: "Fri Aug 16", amount: 4200, expected: 4500, status: "short" },
      { date: "Thu Aug 15", amount: 4500, expected: 4500, status: "paid" },
      { date: "Wed Aug 14", amount: 0, expected: 4500, status: "late" },
      { date: "Tue Aug 13", amount: 4500, expected: 4500, status: "paid" },
    ],
  },
];

const MAINTENANCE_ALERTS: MaintenanceAlert[] = [
  { id: 1, plate: "KDG 567M", driver: "Peter Omondi", type: "Matatu", urgency: "critical", issue: "Brake pads critically worn — immediate replacement required", mileage: 94950, dueAt: 95000, daysOverdue: 3 },
  { id: 2, plate: "KBZ 234K", driver: "Joseph Kamau", type: "Matatu", urgency: "high", issue: "Engine oil and filter service overdue", mileage: 82450, dueAt: 85000, daysOverdue: 0 },
  { id: 3, plate: "KDD 789P", driver: "David Mwangi", type: "Matatu", urgency: "high", issue: "Front tyre rotation and wheel balancing", mileage: 71200, dueAt: 72000, daysOverdue: 0 },
  { id: 4, plate: "KCA 891B", driver: "Grace Wanjiku", type: "Boda Boda", urgency: "medium", issue: "Chain lubrication and brake cable adjustment", mileage: 28900, dueAt: 30000, daysOverdue: 0 },
  { id: 5, plate: "KCH 321R", driver: "Esther Nyambura", type: "Boda Boda", urgency: "low", issue: "Scheduled 30,000 km full service inspection", mileage: 29200, dueAt: 30000, daysOverdue: 0 },
];

// ─── Shared Components ───────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const configs: Record<string, string> = {
    paid: "bg-green-50 text-green-700 border-green-200",
    short: "bg-amber-50 text-amber-700 border-amber-200",
    late: "bg-orange-50 text-orange-700 border-orange-200",
    overdue: "bg-red-50 text-red-700 border-red-200",
  };
  const labels: Record<string, string> = { paid: "Paid", short: "Short", late: "Late", overdue: "Overdue" };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${configs[status] ?? "bg-slate-100 text-slate-600 border-slate-200"}`}>
      {labels[status] ?? status}
    </span>
  );
}

function UrgencyBadge({ urgency }: { urgency: string }) {
  const configs: Record<string, string> = {
    critical: "bg-red-50 text-red-700 border-red-200",
    high: "bg-orange-50 text-orange-700 border-orange-200",
    medium: "bg-amber-50 text-amber-700 border-amber-200",
    low: "bg-sky-50 text-sky-700 border-sky-200",
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border uppercase tracking-wider ${configs[urgency] ?? ""}`}>
      {urgency}
    </span>
  );
}

function Avatar({ initials, size = "md" }: { initials: string; size?: "sm" | "md" | "lg" }) {
  const sizes: Record<string, string> = {
    sm: "w-7 h-7 text-[10px]",
    md: "w-9 h-9 text-xs",
    lg: "w-12 h-12 text-sm",
  };
  return (
    <div className={`${sizes[size]} rounded-full bg-[#1E3A5F] text-white flex items-center justify-center font-bold flex-shrink-0 tracking-wide`}>
      {initials}
    </div>
  );
}

function fmt(n: number) {
  return `KES ${n.toLocaleString()}`;
}

// ─── Login Screen ─────────────────────────────────────────────────────────────

function LoginScreen({ onLogin }: { onLogin: (role: Role) => void }) {
  const [role, setRole] = useState<Role>("owner");
  const [tab, setTab] = useState<"login" | "register">("login");
  const [showPass, setShowPass] = useState(false);
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Brand Panel */}
      <div className="hidden lg:flex flex-col justify-between w-[480px] flex-shrink-0 bg-[#0F2440] text-white p-12 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-16 -right-16 w-80 h-80 rounded-full border border-white/5" />
          <div className="absolute top-20 -right-8 w-56 h-56 rounded-full border border-white/5" />
          <div className="absolute -bottom-20 -left-20 w-96 h-96 rounded-full border border-white/5" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-14">
            <div className="w-9 h-9 bg-[#16A34A] rounded-xl flex items-center justify-center">
              <Truck className="w-4.5 h-4.5 text-white" style={{ width: 18, height: 18 }} />
            </div>
            <span className="text-xl font-bold tracking-tight">FleetPesa</span>
          </div>

          <h1 className="text-[2.6rem] font-bold leading-[1.15] mb-5 tracking-tight">
            Your fleet.<br />
            Your money.<br />
            <span className="text-[#16A34A]">In your hands.</span>
          </h1>
          <p className="text-slate-300 text-base leading-relaxed max-w-xs">
            Track daily remittances, monitor vehicle health, and keep your boda boda and matatu fleet running profitably.
          </p>
        </div>

        <div className="relative z-10 space-y-3">
          {[
            { label: "Today's Fleet Revenue", value: "KES 47,850", sub: "↑ 14% vs yesterday", color: "text-green-400" },
            { label: "Remittances Received", value: "9 of 12 drivers", sub: "3 pending follow-up", color: "text-amber-400" },
            { label: "Vehicles Active", value: "11 / 12 on road", sub: "1 in maintenance", color: "text-sky-400" },
          ].map(({ label, value, sub, color }) => (
            <div key={label} className="flex items-center gap-4 bg-white/5 hover:bg-white/8 rounded-xl p-4 border border-white/8 transition-colors">
              <div className={`w-2 h-2 rounded-full flex-shrink-0 ${color.replace("text-", "bg-")}`} />
              <div className="flex-1 min-w-0">
                <div className="text-xs text-slate-400">{label}</div>
                <div className="text-white font-semibold text-sm mt-0.5">{value}</div>
              </div>
              <span className={`text-xs font-medium ${color}`}>{sub}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Form Panel */}
      <div className="flex-1 flex items-center justify-center p-6 bg-[#F1F5F9]">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2.5 mb-8 lg:hidden">
            <div className="w-8 h-8 bg-[#0F2440] rounded-xl flex items-center justify-center">
              <Truck className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-[#0F2440] text-lg">FleetPesa</span>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-sm border border-black/[0.06]">
            <h2 className="text-[1.5rem] font-bold text-[#0F2440] mb-1 tracking-tight">
              {tab === "login" ? "Welcome back" : "Create account"}
            </h2>
            <p className="text-slate-400 text-sm mb-7">
              {tab === "login" ? "Sign in to your fleet dashboard" : "Get started with FleetPesa today"}
            </p>

            {/* Role Toggle */}
            <div className="flex rounded-xl bg-[#F1F5F9] p-1 mb-6">
              {(["owner", "driver"] as Role[]).map((r) => (
                <button
                  key={r}
                  onClick={() => setRole(r)}
                  className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all duration-150 ${
                    role === r
                      ? "bg-white text-[#1E3A5F] shadow-sm"
                      : "text-slate-400 hover:text-slate-600"
                  }`}
                >
                  {r === "owner" ? "Fleet Owner" : "Driver"}
                </button>
              ))}
            </div>

            <div className="space-y-4">
              {tab === "register" && (
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Joseph Kamau"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/20 focus:border-[#1E3A5F] bg-white transition-colors"
                  />
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Phone Number</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+254 712 345 678"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/20 focus:border-[#1E3A5F] bg-white transition-colors"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Password</label>
                <div className="relative">
                  <input
                    type={showPass ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 py-3 pr-12 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/20 focus:border-[#1E3A5F] bg-white transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 transition-colors"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={() => onLogin(role)}
              className="w-full mt-6 py-3 bg-[#1E3A5F] text-white rounded-xl font-semibold text-sm hover:bg-[#162D4A] active:scale-[0.98] transition-all duration-150"
            >
              {tab === "login" ? "Sign In" : "Create Account"}
            </button>

            <p className="text-center text-sm text-slate-400 mt-5">
              {tab === "login" ? "No account yet? " : "Already have an account? "}
              <button
                onClick={() => setTab(tab === "login" ? "register" : "login")}
                className="text-[#1E3A5F] font-semibold hover:underline"
              >
                {tab === "login" ? "Sign up" : "Sign in"}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

function Sidebar({
  activeTab,
  setActiveTab,
  onLogout,
  setSelectedVehicle,
}: {
  activeTab: SidebarTab;
  setActiveTab: (t: SidebarTab) => void;
  onLogout: () => void;
  setSelectedVehicle: (v: Vehicle | null) => void;
}) {
  const items: { id: SidebarTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "fleet", label: "Fleet", icon: Truck },
    { id: "maintenance", label: "Maintenance", icon: Wrench },
  ];

  return (
    <aside className="hidden md:flex flex-col w-56 bg-[#0F2440] text-white h-screen flex-shrink-0">
      <div className="flex items-center gap-3 px-5 py-5 border-b border-white/[0.08]">
        <div className="w-8 h-8 bg-[#16A34A] rounded-lg flex items-center justify-center flex-shrink-0">
          <Truck className="w-4 h-4 text-white" />
        </div>
        <span className="font-bold tracking-tight text-[15px]">FleetPesa</span>
      </div>

      <div className="px-3 py-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-3 px-3 py-3">
          <div className="w-8 h-8 rounded-full bg-[#1E3A5F] text-white flex items-center justify-center text-xs font-bold">MO</div>
          <div>
            <div className="text-xs font-semibold">Martin Otieno</div>
            <div className="text-[10px] text-white/50">Fleet Owner</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-3 space-y-0.5">
        {items.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => { setActiveTab(id); setSelectedVehicle(null); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] font-medium transition-all ${
              activeTab === id
                ? "bg-white/[0.12] text-white"
                : "text-white/50 hover:text-white hover:bg-white/[0.06]"
            }`}
          >
            <Icon className="w-4 h-4 flex-shrink-0" />
            {label}
            {id === "maintenance" && (
              <span className="ml-auto bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">3</span>
            )}
          </button>
        ))}
      </nav>

      <div className="px-3 py-3 border-t border-white/[0.08] space-y-0.5">
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] text-white/50 hover:text-white hover:bg-white/[0.06] transition-all">
          <Settings className="w-4 h-4" />
          Settings
        </button>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] text-white/50 hover:text-white hover:bg-white/[0.06] transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({
  label, value, trendLabel, trend, icon: Icon, accentClass,
}: {
  label: string;
  value: string;
  trendLabel?: string;
  trend?: "up" | "down" | "neutral";
  icon: React.ComponentType<{ className?: string }>;
  accentClass: string;
}) {
  const trendColor = trend === "up" ? "text-green-600" : trend === "down" ? "text-red-500" : "text-slate-400";
  return (
    <div className="bg-white rounded-2xl p-5 border border-black/[0.06] shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${accentClass}`}>
          <Icon className="w-4 h-4" />
        </div>
        {trendLabel && (
          <span className={`text-[11px] font-semibold ${trendColor}`}>{trendLabel}</span>
        )}
      </div>
      <div className="text-[1.4rem] font-bold text-[#0F2440] leading-none mb-1.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
        {value}
      </div>
      <div className="text-xs text-slate-400 font-medium">{label}</div>
    </div>
  );
}

// ─── Dashboard Screen ─────────────────────────────────────────────────────────

function DashboardScreen({
  onSelectVehicle,
  onSelectDriver,
}: {
  onSelectVehicle: (v: Vehicle) => void;
  onSelectDriver: (d: Driver) => void;
}) {
  const totalCollected = DRIVERS.reduce((sum, d) => sum + d.collected, 0);
  const totalOutstanding = DRIVERS.reduce((sum, d) => sum + Math.max(0, d.expected - d.collected), 0);
  const activeDrivers = DRIVERS.filter((d) => d.status === "paid" || d.status === "short").length;

  return (
    <div className="flex-1 overflow-auto min-h-0">
      {/* Top bar */}
      <div className="bg-white border-b border-black/[0.06] px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div>
          <h1 className="text-base font-bold text-[#0F2440]">Dashboard</h1>
          <p className="text-xs text-slate-400 mt-0.5">Sunday, 18 August 2025</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="relative p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors">
            <Bell className="w-4.5 h-4.5" style={{ width: 18, height: 18 }} />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
          </button>
          <div className="w-8 h-8 rounded-full bg-[#1E3A5F] text-white flex items-center justify-center text-[10px] font-bold">MO</div>
        </div>
      </div>

      <div className="p-6 space-y-5">
        {/* Stat Cards */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard label="Today's Revenue" value={fmt(totalCollected)} icon={TrendingUp} trend="up" trendLabel="↑ 14% vs yesterday" accentClass="bg-green-50 text-green-600" />
          <StatCard label="Outstanding" value={fmt(totalOutstanding)} icon={Clock} trend="down" trendLabel="4 drivers pending" accentClass="bg-amber-50 text-amber-600" />
          <StatCard label="Service Due" value="3 vehicles" icon={Wrench} trend="down" trendLabel="1 critical" accentClass="bg-red-50 text-red-500" />
          <StatCard label="Active Drivers" value={`${activeDrivers} / ${DRIVERS.length}`} icon={Users} trend="neutral" trendLabel="1 offline today" accentClass="bg-sky-50 text-sky-600" />
        </div>

        {/* Revenue Chart */}
        <div className="bg-white rounded-2xl p-6 border border-black/[0.06] shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-sm font-bold text-[#0F2440]">Weekly Revenue</h2>
              <p className="text-xs text-slate-400 mt-0.5">Last 7 days · daily target KES 42,000</p>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#1E3A5F] inline-block" />Revenue</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#16A34A] inline-block" />Target</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={REVENUE_DATA} margin={{ top: 4, right: 4, bottom: 0, left: -24 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#1E3A5F" stopOpacity={0.15} />
                  <stop offset="100%" stopColor="#1E3A5F" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#94A3B8", fontFamily: "Inter, sans-serif" }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#94A3B8", fontFamily: "Inter, sans-serif" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ background: "#0F2440", border: "none", borderRadius: "10px", fontSize: "12px", color: "#fff", fontFamily: "Inter, sans-serif" }}
                formatter={(value: number) => [`KES ${value.toLocaleString()}`, "Revenue"]}
                cursor={{ stroke: "#1E3A5F", strokeWidth: 1, strokeDasharray: "3 3" }}
              />
              <Area type="monotone" dataKey="revenue" stroke="#1E3A5F" strokeWidth={2} fill="url(#revGrad)" dot={false} activeDot={{ r: 4, fill: "#1E3A5F", strokeWidth: 0 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Remittance Table */}
        <div className="bg-white rounded-2xl border border-black/[0.06] shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-50 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#0F2440]">Driver Remittances</h2>
              <p className="text-xs text-slate-400 mt-0.5">Today&apos;s collection status</p>
            </div>
            <button className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-600 border border-slate-200 rounded-lg px-3 py-1.5 transition-colors">
              <Filter className="w-3 h-3" />
              Filter
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-50">
                  {["Driver", "Vehicle", "Collected", "Status", "Time", ""].map((h, i) => (
                    <th key={i} className={`text-left text-[10px] font-bold text-slate-300 px-5 py-3 uppercase tracking-wider ${i >= 2 && i < 4 ? "hidden sm:table-cell" : i === 4 ? "hidden lg:table-cell" : ""}`}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {DRIVERS.map((d) => (
                  <tr key={d.id} className="border-b border-slate-50/80 hover:bg-slate-50/50 transition-colors group last:border-0">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <Avatar initials={d.initials} size="sm" />
                        <div>
                          <div className="text-sm font-semibold text-[#0F2440]">{d.name}</div>
                          <div className="text-[10px] text-slate-400">{d.type}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-sm text-slate-600" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{d.vehicle}</span>
                    </td>
                    <td className="px-5 py-3.5 hidden sm:table-cell">
                      <div className="text-sm font-semibold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{fmt(d.collected)}</div>
                      <div className="text-[10px] text-slate-400">of {fmt(d.expected)}</div>
                    </td>
                    <td className="px-5 py-3.5 hidden sm:table-cell">
                      <StatusBadge status={d.status} />
                    </td>
                    <td className="px-5 py-3.5 hidden lg:table-cell">
                      <span className="text-xs text-slate-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{d.time}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <button
                        onClick={() => onSelectDriver(d)}
                        className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all ${
                          d.status === "short" || d.status === "overdue"
                            ? "bg-red-50 text-red-600 hover:bg-red-100"
                            : "text-slate-300 hover:text-slate-500 opacity-0 group-hover:opacity-100"
                        }`}
                      >
                        {d.status === "short" || d.status === "overdue" ? "Review" : "Details"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Fleet Screen ─────────────────────────────────────────────────────────────

function FleetScreen({ onSelectVehicle }: { onSelectVehicle: (v: Vehicle) => void }) {
  return (
    <div className="flex-1 overflow-auto min-h-0">
      <div className="bg-white border-b border-black/[0.06] px-6 py-4 sticky top-0 z-10">
        <h1 className="text-base font-bold text-[#0F2440]">Fleet</h1>
        <p className="text-xs text-slate-400 mt-0.5">12 registered vehicles</p>
      </div>
      <div className="p-6 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {DRIVERS.map((d) => (
          <button
            key={d.id}
            onClick={() => onSelectVehicle(VEHICLES[0])}
            className="bg-white rounded-2xl p-5 border border-black/[0.06] shadow-sm hover:shadow-md hover:border-[#1E3A5F]/15 transition-all text-left group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 bg-[#EDF2F7] rounded-xl flex items-center justify-center group-hover:bg-[#E8EEF7] transition-colors">
                  {d.type === "Matatu"
                    ? <Truck className="w-5 h-5 text-[#1E3A5F]" />
                    : <Bike className="w-5 h-5 text-[#1E3A5F]" />}
                </div>
                <div>
                  <div className="font-bold text-[#0F2440] text-sm" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{d.vehicle}</div>
                  <div className="text-[10px] text-slate-400">{d.type}</div>
                </div>
              </div>
              <StatusBadge status={d.status} />
            </div>
            <div className="flex items-center gap-2.5 pt-3 border-t border-slate-50">
              <Avatar initials={d.initials} size="sm" />
              <span className="text-xs font-medium text-slate-600">{d.name}</span>
              <ChevronRight className="w-3 h-3 text-slate-300 ml-auto" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Vehicle Detail Screen ────────────────────────────────────────────────────

function VehicleDetailScreen({ vehicle, onBack }: { vehicle: Vehicle; onBack: () => void }) {
  const serviceKmLeft = vehicle.nextService - vehicle.mileage;
  const servicePct = Math.min(100, ((vehicle.mileage - (vehicle.nextService - 5000)) / 5000) * 100);

  return (
    <div className="flex-1 overflow-auto min-h-0">
      <div className="bg-white border-b border-black/[0.06] px-6 py-4 sticky top-0 z-10">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#1E3A5F] font-medium mb-2 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Fleet
        </button>
        <h1 className="text-base font-bold text-[#0F2440]">Vehicle Detail</h1>
      </div>

      <div className="p-6 space-y-4 max-w-2xl">
        {/* Profile Card */}
        <div className="bg-white rounded-2xl p-6 border border-black/[0.06] shadow-sm">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-[#EDF2F7] rounded-2xl flex items-center justify-center flex-shrink-0">
              <Truck className="w-8 h-8 text-[#1E3A5F]" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <h2 className="text-xl font-bold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{vehicle.plate}</h2>
                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${
                  vehicle.status === "operational"
                    ? "bg-green-50 text-green-700 border-green-200"
                    : "bg-amber-50 text-amber-700 border-amber-200"
                }`}>
                  {vehicle.status === "operational" ? "Operational" : "In Maintenance"}
                </span>
              </div>
              <p className="text-sm text-slate-400">{vehicle.type} · Assigned to {vehicle.driver}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-5 pt-5 border-t border-slate-50">
            {[
              { label: "Current Mileage", value: `${vehicle.mileage.toLocaleString()} km` },
              { label: "Next Service", value: `${vehicle.nextService.toLocaleString()} km` },
              { label: "Last Serviced", value: vehicle.lastServiceDate },
            ].map(({ label, value }) => (
              <div key={label}>
                <div className="text-[10px] text-slate-400 mb-1 font-medium uppercase tracking-wide">{label}</div>
                <div className="text-sm font-bold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{value}</div>
              </div>
            ))}
          </div>

          <div className="mt-5">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-slate-500 font-medium">Service interval</span>
              <span className={`font-semibold ${servicePct > 80 ? "text-amber-600" : "text-slate-400"}`}>
                {serviceKmLeft.toLocaleString()} km remaining
              </span>
            </div>
            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${servicePct > 80 ? "bg-amber-400" : "bg-[#16A34A]"}`}
                style={{ width: `${servicePct}%` }}
              />
            </div>
          </div>
        </div>

        {/* Driver Card */}
        <div className="bg-white rounded-2xl p-5 border border-black/[0.06] shadow-sm">
          <div className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mb-4">Assigned Driver</div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar initials={vehicle.driverInitials} size="md" />
              <div>
                <div className="font-semibold text-[#0F2440] text-sm">{vehicle.driver}</div>
                <div className="text-xs text-slate-400 mt-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>+254 712 345 678</div>
              </div>
            </div>
            <button className="flex items-center gap-2 text-xs font-semibold text-[#1E3A5F] border border-[#1E3A5F]/20 bg-[#1E3A5F]/[0.04] hover:bg-[#1E3A5F]/[0.08] rounded-xl px-4 py-2 transition-colors">
              <Phone className="w-3.5 h-3.5" />
              Call Driver
            </button>
          </div>
        </div>

        {/* Remittance History */}
        <div className="bg-white rounded-2xl p-6 border border-black/[0.06] shadow-sm">
          <div className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mb-5">Remittance History</div>
          <div>
            {vehicle.remittanceHistory.map((entry, i) => (
              <div key={i} className="flex gap-4 pb-4 last:pb-0">
                <div className="flex flex-col items-center mt-1">
                  <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                    entry.status === "paid" ? "bg-green-500" :
                    entry.status === "short" ? "bg-amber-400" : "bg-red-400"
                  }`} />
                  {i < vehicle.remittanceHistory.length - 1 && (
                    <div className="w-px flex-1 bg-slate-100 mt-1" />
                  )}
                </div>
                <div className="flex-1 flex items-start justify-between pb-4 border-b border-slate-50 last:border-0 last:pb-0">
                  <div>
                    <div className="text-xs font-semibold text-[#0F2440]">{entry.date}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {entry.status === "paid" ? "Full payment received" :
                       entry.status === "short" ? `KES ${(entry.expected - entry.amount).toLocaleString()} short` :
                       "No payment recorded"}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-sm font-bold mb-1 ${
                      entry.status === "paid" ? "text-green-600" :
                      entry.status === "short" ? "text-amber-600" : "text-red-500"
                    }`} style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {entry.amount > 0 ? `KES ${entry.amount.toLocaleString()}` : "—"}
                    </div>
                    <StatusBadge status={entry.status} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Maintenance Screen ───────────────────────────────────────────────────────

function MaintenanceScreen() {
  const [alerts, setAlerts] = useState<MaintenanceAlert[]>(MAINTENANCE_ALERTS);

  const markServiced = (id: number) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, serviced: true } : a)));
  };

  const urgencyOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
  const sorted = [...alerts].sort((a, b) => urgencyOrder[a.urgency] - urgencyOrder[b.urgency]);
  const pendingCount = alerts.filter((a) => !a.serviced).length;

  return (
    <div className="flex-1 overflow-auto min-h-0">
      <div className="bg-white border-b border-black/[0.06] px-6 py-4 sticky top-0 z-10">
        <h1 className="text-base font-bold text-[#0F2440]">Maintenance Alerts</h1>
        <p className="text-xs text-slate-400 mt-0.5">{pendingCount} vehicles requiring attention</p>
      </div>

      <div className="p-6 space-y-4 max-w-2xl">
        {/* Critical banner */}
        {alerts.some((a) => a.urgency === "critical" && !a.serviced) && (
          <div className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-2xl p-4">
            <AlertTriangle className="w-4.5 h-4.5 text-red-600 flex-shrink-0 mt-0.5" style={{ width: 18, height: 18 }} />
            <div>
              <div className="text-sm font-bold text-red-800">Critical Safety Issue</div>
              <div className="text-xs text-red-600 mt-0.5 leading-relaxed">
                KDG 567M has critically worn brake pads. Remove this vehicle from service immediately until repaired.
              </div>
            </div>
          </div>
        )}

        {sorted.map((alert) => (
          <div
            key={alert.id}
            className={`bg-white rounded-2xl border shadow-sm overflow-hidden transition-all ${
              alert.serviced
                ? "opacity-40 border-slate-100"
                : alert.urgency === "critical"
                ? "border-red-200"
                : "border-black/[0.06]"
            }`}
          >
            <div className={`h-0.5 ${
              alert.urgency === "critical" ? "bg-red-500" :
              alert.urgency === "high" ? "bg-orange-400" :
              alert.urgency === "medium" ? "bg-amber-400" : "bg-sky-400"
            }`} />
            <div className="p-5">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    alert.urgency === "critical" ? "bg-red-50" :
                    alert.urgency === "high" ? "bg-orange-50" :
                    alert.urgency === "medium" ? "bg-amber-50" : "bg-sky-50"
                  }`}>
                    <Wrench className={`w-4 h-4 ${
                      alert.urgency === "critical" ? "text-red-600" :
                      alert.urgency === "high" ? "text-orange-600" :
                      alert.urgency === "medium" ? "text-amber-600" : "text-sky-600"
                    }`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#0F2440] text-sm" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{alert.plate}</span>
                      <span className="text-[10px] text-slate-400">{alert.type}</span>
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">{alert.driver}</div>
                  </div>
                </div>
                <UrgencyBadge urgency={alert.urgency} />
              </div>

              <p className="text-sm text-slate-600 leading-relaxed mb-4">{alert.issue}</p>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-[10px] text-slate-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  <span>{alert.mileage.toLocaleString()} km now</span>
                  <span className="text-slate-200">·</span>
                  <span>{alert.dueAt.toLocaleString()} km due</span>
                  {alert.daysOverdue > 0 && (
                    <span className="text-red-600 font-semibold not-mono" style={{ fontFamily: "Inter, sans-serif" }}>
                      {alert.daysOverdue}d overdue
                    </span>
                  )}
                </div>
                {!alert.serviced ? (
                  <button
                    onClick={() => markServiced(alert.id)}
                    className="flex items-center gap-1.5 text-xs font-semibold text-[#16A34A] border border-green-200 bg-green-50 hover:bg-green-100 rounded-xl px-3 py-1.5 transition-colors"
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    Mark Serviced
                  </button>
                ) : (
                  <span className="flex items-center gap-1.5 text-xs text-green-600 font-semibold">
                    <CheckCircle className="w-3.5 h-3.5" /> Serviced
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Shortfall Modal ──────────────────────────────────────────────────────────

function ShortfallModal({ driver, onClose }: { driver: Driver; onClose: () => void }) {
  const shortfall = driver.expected - driver.collected;
  const [flagged, setFlagged] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-black/10 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-[#0F2440] px-6 py-5 flex items-start justify-between">
          <div>
            <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-2">Shortfall Review</div>
            <h3 className="text-white font-bold text-[1.1rem] leading-tight">{driver.name}</h3>
            <div className="text-white/50 text-xs mt-1" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
              {driver.vehicle} · {driver.type}
            </div>
          </div>
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors mt-0.5">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 py-5 border-b border-slate-50">
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-2">Expected</div>
              <div className="text-2xl font-bold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                {fmt(driver.expected)}
              </div>
            </div>
            <div className={`rounded-xl p-4 ${driver.collected > 0 ? "bg-amber-50" : "bg-red-50"}`}>
              <div className={`text-[10px] font-semibold uppercase tracking-wide mb-2 ${driver.collected > 0 ? "text-amber-500" : "text-red-400"}`}>
                Collected
              </div>
              <div className={`text-2xl font-bold ${driver.collected > 0 ? "text-amber-700" : "text-red-600"}`} style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                {driver.collected > 0 ? fmt(driver.collected) : "—"}
              </div>
            </div>
          </div>

          <div className={`flex items-center justify-between px-4 py-3 rounded-xl border ${
            driver.status === "overdue" ? "bg-red-50 border-red-200" : "bg-amber-50 border-amber-200"
          }`}>
            <div className="flex items-center gap-2">
              <AlertTriangle className={`w-4 h-4 ${driver.status === "overdue" ? "text-red-600" : "text-amber-600"}`} />
              <span className={`text-sm font-bold ${driver.status === "overdue" ? "text-red-700" : "text-amber-700"}`}>
                {driver.status === "overdue" ? "Full amount missing" : `${fmt(shortfall)} short`}
              </span>
            </div>
            <StatusBadge status={driver.status} />
          </div>
        </div>

        <div className="px-6 py-4 border-b border-slate-50">
          <div className="flex items-center gap-3 mb-3">
            <Avatar initials={driver.initials} size="md" />
            <div>
              <div className="font-semibold text-[#0F2440] text-sm">{driver.name}</div>
              <div className="text-xs text-slate-400 mt-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{driver.phone}</div>
            </div>
          </div>
          <div className="flex items-start gap-2 text-xs text-slate-400">
            <Clock className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
            <span>
              {driver.time === "—"
                ? "No remittance received today"
                : `Partial payment submitted at ${driver.time}`}
            </span>
          </div>
        </div>

        <div className="px-6 py-4 flex gap-3">
          <button
            onClick={() => { setFlagged(true); setTimeout(onClose, 900); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 ${
              flagged
                ? "bg-red-600 text-white scale-[0.98]"
                : "bg-red-50 text-red-600 border border-red-200 hover:bg-red-100"
            }`}
          >
            <Flag className="w-3.5 h-3.5" />
            {flagged ? "Flagged!" : "Flag for Follow-up"}
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-slate-100 text-slate-500 hover:bg-slate-200 transition-colors"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Driver Remittance Screen (mobile) ───────────────────────────────────────

interface PromptRecord {
  id: number;
  phone: string;
  amount: number;
  status: "paid" | "pending" | "expired";
  time: string;
}

function RemittanceScreen({ onLogout }: { onLogout: () => void }) {
  const [driverTab, setDriverTab] = useState<"remittance" | "prompt">("remittance");

  // Remittance state
  const [amount, setAmount] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [remLoading, setRemLoading] = useState(false);

  // Prompt state
  const [promptPhone, setPromptPhone] = useState("");
  const [promptAmount, setPromptAmount] = useState("");
  const [promptState, setPromptState] = useState<"idle" | "sending" | "sent">("idle");
  const [prompts, setPrompts] = useState<PromptRecord[]>([
    { id: 1, phone: "+254 712 ***678", amount: 150, status: "paid", time: "09:12 AM" },
    { id: 2, phone: "+254 723 ***789", amount: 100, status: "pending", time: "09:47 AM" },
    { id: 3, phone: "+254 756 ***012", amount: 80, status: "expired", time: "08:30 AM" },
  ]);

  const numAmount = parseFloat(amount) || 0;
  const numPromptAmount = parseFloat(promptAmount) || 0;
  const expected = 4500;
  const isShort = numAmount > 0 && numAmount < expected;
  const canPrompt = promptPhone.replace(/\D/g, "").length >= 9 && numPromptAmount > 0;

  const handleSubmit = () => {
    if (numAmount <= 0) return;
    setRemLoading(true);
    setTimeout(() => { setRemLoading(false); setSubmitted(true); }, 1400);
  };

  const handlePrompt = () => {
    if (!canPrompt) return;
    setPromptState("sending");
    setTimeout(() => {
      const digits = promptPhone.replace(/\D/g, "");
      const masked = `+254 ${digits.slice(0, 3)} ***${digits.slice(-3)}`;
      setPrompts((prev) => [
        {
          id: Date.now(),
          phone: masked,
          amount: numPromptAmount,
          status: "pending",
          time: new Date().toLocaleTimeString("en-KE", { hour: "2-digit", minute: "2-digit" }),
        },
        ...prev.slice(0, 4),
      ]);
      setPromptState("sent");
      setTimeout(() => {
        setPromptState("idle");
        setPromptPhone("");
        setPromptAmount("");
      }, 3000);
    }, 1600);
  };

  // ── Remittance success screen ──
  if (submitted) {
    return (
      <div className="min-h-screen bg-[#F1F5F9] flex flex-col items-center justify-center p-6" style={{ fontFamily: "'Inter', sans-serif" }}>
        <div className="w-full max-w-xs bg-white rounded-3xl p-8 shadow-sm border border-black/[0.06] text-center">
          <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-5">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-[#0F2440] mb-1">Payment Received!</h2>
          <p className="text-sm text-slate-400 mb-1">Successfully remitted</p>
          <p className="text-2xl font-bold text-[#0F2440] mb-5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            KES {numAmount.toLocaleString()}
          </p>
          <div className="bg-[#F1F5F9] rounded-xl p-4 mb-6 text-left space-y-2.5">
            {[
              ["Reference", "FP-2025-001847"],
              ["M-Pesa Code", "QHF72JKM8N"],
              ["Vehicle", "KDG 567M"],
              ["Time", "11:32 AM · Sun Aug 18"],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between text-xs">
                <span className="text-slate-400">{label}</span>
                <span className="font-semibold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{value}</span>
              </div>
            ))}
          </div>
          <button
            onClick={() => { setSubmitted(false); setAmount(""); }}
            className="w-full py-3 bg-[#1E3A5F] text-white rounded-xl font-semibold text-sm hover:bg-[#162D4A] transition-colors"
          >
            Submit Another
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F1F5F9] flex flex-col" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="bg-[#0F2440] text-white px-5 pt-10 pb-5">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-[#16A34A] rounded-lg flex items-center justify-center">
              <Truck className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-bold text-sm">FleetPesa</span>
          </div>
          <button onClick={onLogout} className="text-white/50 text-xs hover:text-white transition-colors">Sign out</button>
        </div>
        <div className="flex items-center gap-3 mb-5">
          <Avatar initials="PO" size="md" />
          <div>
            <div className="font-bold text-base leading-tight">Peter Omondi</div>
            <div className="text-white/50 text-xs mt-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>KDG 567M · Matatu</div>
          </div>
        </div>

        {/* Tab bar inside header */}
        <div className="flex rounded-xl bg-white/[0.08] p-1">
          <button
            onClick={() => setDriverTab("remittance")}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
              driverTab === "remittance"
                ? "bg-white text-[#1E3A5F] shadow-sm"
                : "text-white/50 hover:text-white"
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            Daily Remittance
          </button>
          <button
            onClick={() => setDriverTab("prompt")}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
              driverTab === "prompt"
                ? "bg-white text-[#1E3A5F] shadow-sm"
                : "text-white/50 hover:text-white"
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            Prompt Passenger
          </button>
        </div>
      </div>

      {/* ── Remittance tab ── */}
      {driverTab === "remittance" && (
        <div className="flex-1 px-5 py-5 space-y-4">
          {/* Amount input */}
          <div className="bg-white rounded-2xl p-5 border border-black/[0.06] shadow-sm">
            <div className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mb-4">Amount to submit</div>
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold text-slate-200" style={{ fontFamily: "'JetBrains Mono', monospace" }}>KES</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                className="flex-1 text-right text-4xl font-bold text-[#0F2440] bg-transparent border-none outline-none"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              />
            </div>
            <div className="h-px bg-slate-100 my-4" />
            <div className="flex justify-between items-center text-sm">
              <span className="text-slate-400">Expected today</span>
              <span className="font-bold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>KES {expected.toLocaleString()}</span>
            </div>
            {isShort && (
              <div className="mt-3 flex items-center gap-1.5 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 font-medium">
                <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                KES {(expected - numAmount).toLocaleString()} short of daily target — owner will be notified
              </div>
            )}
          </div>

          {/* Quick amounts */}
          <div>
            <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mb-2.5">Quick select</p>
            <div className="grid grid-cols-3 gap-2">
              {[1500, 3000, 4500].map((v) => (
                <button
                  key={v}
                  onClick={() => setAmount(v.toString())}
                  className={`py-2.5 rounded-xl text-sm font-bold border transition-all ${
                    amount === v.toString()
                      ? "bg-[#1E3A5F] text-white border-transparent shadow-sm"
                      : "bg-white text-slate-600 border-slate-200 hover:border-[#1E3A5F]/30 hover:text-[#1E3A5F]"
                  }`}
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {v.toLocaleString()}
                </button>
              ))}
            </div>
          </div>

          {/* Payment method */}
          <div className="bg-white rounded-2xl p-4 border border-black/[0.06] shadow-sm flex items-center gap-3">
            <div className="w-9 h-9 bg-green-50 rounded-xl flex items-center justify-center flex-shrink-0">
              <Phone className="w-4 h-4 text-green-600" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold text-[#0F2440]">M-Pesa</div>
              <div className="text-xs text-slate-400 mt-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>+254 734 567 890</div>
            </div>
            <span className="text-[10px] font-bold text-green-700 bg-green-50 border border-green-200 px-2.5 py-1 rounded-full uppercase tracking-wide">Ready</span>
          </div>

          <button
            onClick={handleSubmit}
            disabled={numAmount <= 0 || remLoading}
            className={`w-full py-4 rounded-2xl font-bold text-base transition-all duration-150 ${
              remLoading
                ? "bg-[#16A34A] text-white"
                : numAmount <= 0
                ? "bg-slate-200 text-slate-400 cursor-not-allowed"
                : "bg-[#1E3A5F] text-white hover:bg-[#162D4A] active:scale-[0.98]"
            }`}
          >
            {remLoading ? "Processing..." : numAmount > 0 ? `Submit ${fmt(numAmount)}` : "Enter an amount"}
          </button>
        </div>
      )}

      {/* ── Prompt Passenger tab ── */}
      {driverTab === "prompt" && (
        <div className="flex-1 px-5 py-5 space-y-4">

          {/* Prompt sent confirmation banner */}
          {promptState === "sent" && (
            <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-2xl px-4 py-3.5">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <CheckCircle className="w-4 h-4 text-green-600" />
              </div>
              <div>
                <div className="text-sm font-bold text-green-800">Prompt sent!</div>
                <div className="text-xs text-green-600 mt-0.5">Passenger will receive an M-Pesa STK push now</div>
              </div>
            </div>
          )}

          {/* Main prompt card */}
          <div className="bg-white rounded-2xl p-5 border border-black/[0.06] shadow-sm space-y-5">
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <Zap className="w-3.5 h-3.5 text-[#1E3A5F]" />
                <span className="text-sm font-bold text-[#0F2440]">Prompt Passenger</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Enter the passenger&apos;s phone number and fare. They&apos;ll get an M-Pesa prompt — payment goes straight to your number.
              </p>
            </div>

            {/* Phone number */}
            <div>
              <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-widest mb-2">
                Passenger phone number
              </label>
              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                  <span className="text-sm font-semibold text-slate-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>+254</span>
                  <span className="w-px h-4 bg-slate-200" />
                </div>
                <input
                  type="tel"
                  value={promptPhone}
                  onChange={(e) => setPromptPhone(e.target.value)}
                  placeholder="7XX XXX XXX"
                  className="w-full pl-16 pr-4 py-3 rounded-xl border border-slate-200 text-sm font-semibold text-[#0F2440] focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/20 focus:border-[#1E3A5F] transition-colors bg-[#F8FAFC]"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                />
              </div>
            </div>

            {/* Fare amount */}
            <div>
              <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-widest mb-2">
                Fare amount (KES)
              </label>
              <div className="flex items-baseline gap-2 border border-slate-200 rounded-xl px-4 py-3 bg-[#F8FAFC] focus-within:ring-2 focus-within:ring-[#1E3A5F]/20 focus-within:border-[#1E3A5F] transition-colors">
                <span className="text-base font-bold text-slate-300" style={{ fontFamily: "'JetBrains Mono', monospace" }}>KES</span>
                <input
                  type="number"
                  value={promptAmount}
                  onChange={(e) => setPromptAmount(e.target.value)}
                  placeholder="0"
                  className="flex-1 text-right text-2xl font-bold text-[#0F2440] bg-transparent border-none outline-none"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                />
              </div>

              {/* Common fare quick-picks */}
              <div className="mt-3 grid grid-cols-6 gap-1.5">
                {[30, 50, 80, 100, 150, 200].map((v) => (
                  <button
                    key={v}
                    onClick={() => setPromptAmount(v.toString())}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      promptAmount === v.toString()
                        ? "bg-[#1E3A5F] text-white border-transparent"
                        : "bg-white text-slate-500 border-slate-200 hover:border-[#1E3A5F]/30 hover:text-[#1E3A5F]"
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            {/* Receives-to info */}
            <div className="flex items-center gap-3 bg-[#F1F5F9] rounded-xl px-4 py-3">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Phone className="w-3.5 h-3.5 text-green-600" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[10px] text-slate-400 uppercase tracking-wide font-semibold">Payment received by</div>
                <div className="text-sm font-bold text-[#0F2440] mt-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>+254 734 567 890</div>
              </div>
              <span className="text-[10px] font-bold text-green-700 bg-green-50 border border-green-200 px-2 py-0.5 rounded-full uppercase tracking-wide flex-shrink-0">Your number</span>
            </div>

            <button
              onClick={handlePrompt}
              disabled={!canPrompt || promptState !== "idle"}
              className={`w-full py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all duration-200 ${
                promptState === "sending"
                  ? "bg-[#16A34A] text-white"
                  : promptState === "sent"
                  ? "bg-green-600 text-white"
                  : !canPrompt
                  ? "bg-slate-200 text-slate-400 cursor-not-allowed"
                  : "bg-[#1E3A5F] text-white hover:bg-[#162D4A] active:scale-[0.98]"
              }`}
            >
              {promptState === "sending" ? (
                <>
                  <RotateCcw className="w-4 h-4 animate-spin" />
                  Sending prompt…
                </>
              ) : promptState === "sent" ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Prompt Sent!
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  {canPrompt ? `Send KES ${numPromptAmount.toLocaleString()} Prompt` : "Enter number and amount"}
                </>
              )}
            </button>
          </div>

          {/* Recent prompts */}
          <div>
            <div className="flex items-center gap-1.5 mb-3">
              <History className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Today&apos;s prompts</span>
              <span className="ml-auto text-[10px] font-bold text-slate-300">
                {prompts.filter((p) => p.status === "paid").length} of {prompts.length} paid
              </span>
            </div>

            {prompts.length === 0 ? (
              <div className="bg-white rounded-2xl p-6 border border-black/[0.06] text-center text-xs text-slate-400">
                No prompts sent today
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-black/[0.06] shadow-sm overflow-hidden">
                {prompts.map((p, i) => (
                  <div
                    key={p.id}
                    className={`flex items-center gap-3 px-4 py-3.5 ${i < prompts.length - 1 ? "border-b border-slate-50" : ""}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      p.status === "paid" ? "bg-green-50" :
                      p.status === "pending" ? "bg-amber-50" : "bg-slate-100"
                    }`}>
                      {p.status === "paid"
                        ? <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                        : p.status === "pending"
                        ? <Clock className="w-3.5 h-3.5 text-amber-500" />
                        : <X className="w-3.5 h-3.5 text-slate-400" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{p.phone}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{p.time}</div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-sm font-bold text-[#0F2440]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                        KES {p.amount.toLocaleString()}
                      </div>
                      <div className={`text-[10px] font-semibold mt-0.5 ${
                        p.status === "paid" ? "text-green-600" :
                        p.status === "pending" ? "text-amber-600" : "text-slate-400"
                      }`}>
                        {p.status === "paid" ? "Paid" : p.status === "pending" ? "Awaiting" : "Expired"}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Earnings summary */}
          <div className="bg-[#0F2440] rounded-2xl p-4 flex items-center gap-4">
            <div className="flex-1">
              <div className="text-[10px] text-white/40 uppercase tracking-wide font-semibold mb-1">Prompted earnings today</div>
              <div className="text-xl font-bold text-white" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                KES {prompts.filter(p => p.status === "paid").reduce((s, p) => s + p.amount, 0).toLocaleString()}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-white/40 uppercase tracking-wide font-semibold mb-1">Pending</div>
              <div className="text-base font-bold text-amber-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                KES {prompts.filter(p => p.status === "pending").reduce((s, p) => s + p.amount, 0).toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [role, setRole] = useState<Role>("owner");
  const [activeTab, setActiveTab] = useState<SidebarTab>("dashboard");
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [shortfallDriver, setShortfallDriver] = useState<Driver | null>(null);

  if (!loggedIn) {
    return (
      <LoginScreen
        onLogin={(r) => {
          setRole(r);
          setLoggedIn(true);
        }}
      />
    );
  }

  if (role === "driver") {
    return <RemittanceScreen onLogout={() => setLoggedIn(false)} />;
  }

  const renderContent = () => {
    if (selectedVehicle) {
      return <VehicleDetailScreen vehicle={selectedVehicle} onBack={() => setSelectedVehicle(null)} />;
    }
    if (activeTab === "fleet") {
      return <FleetScreen onSelectVehicle={(v) => setSelectedVehicle(v)} />;
    }
    if (activeTab === "maintenance") {
      return <MaintenanceScreen />;
    }
    return (
      <DashboardScreen
        onSelectVehicle={(v) => { setSelectedVehicle(v); setActiveTab("fleet"); }}
        onSelectDriver={(d) => setShortfallDriver(d)}
      />
    );
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#F1F5F9]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Desktop sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={() => setLoggedIn(false)}
        setSelectedVehicle={setSelectedVehicle}
      />

      {/* Mobile top bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-40 bg-[#0F2440] text-white px-4 h-12 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-[#16A34A] rounded-md flex items-center justify-center">
            <Truck className="w-3 h-3 text-white" />
          </div>
          <span className="font-bold text-sm">FleetPesa</span>
        </div>
        <button className="text-white/60 hover:text-white">
          <Bell className="w-4.5 h-4.5" style={{ width: 18, height: 18 }} />
        </button>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden md:mt-0 mt-12 md:mb-0 mb-14">
        {renderContent()}
      </div>

      {/* Mobile bottom nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 flex px-2 py-1.5 safe-area-bottom">
        {([
          { id: "dashboard" as SidebarTab, label: "Home", icon: LayoutDashboard },
          { id: "fleet" as SidebarTab, label: "Fleet", icon: Truck },
          { id: "maintenance" as SidebarTab, label: "Alerts", icon: Wrench },
        ]).map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => { setActiveTab(id); setSelectedVehicle(null); }}
            className={`flex-1 flex flex-col items-center gap-0.5 py-1 rounded-xl transition-colors ${
              activeTab === id ? "text-[#1E3A5F]" : "text-slate-300 hover:text-slate-500"
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px] font-semibold">{label}</span>
          </button>
        ))}
      </div>

      {/* Shortfall Modal */}
      {shortfallDriver && (
        <ShortfallModal
          driver={shortfallDriver}
          onClose={() => setShortfallDriver(null)}
        />
      )}
    </div>
  );
}
